vendor/
node_modules/
.env
.phpunit.result.cache
.idea/
.vscode/
