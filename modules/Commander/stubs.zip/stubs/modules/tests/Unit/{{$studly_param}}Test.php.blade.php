{!! $opening_tag !!}
/*
 * Copyright (c) {{$year}} - Do Group LLC - All Right Reserved.
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Emanuele (ebalo) Balsamo <emanuele.balsamo@do-inc.co>, {{$year}}
 */

namespace {{$namespace}}\Tests\Unit;

use PHPUnit\Framework\TestCase;

class {{$studly_param}}Test extends TestCase
{
    public function test_example()
    {
        $this->assertTrue(true);
    }
}
