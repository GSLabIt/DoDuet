{!! $opening_tag !!}
/*
* Copyright (c) {{$year}} - Do Group LLC - All Right Reserved.
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
* Written by Emanuele (ebalo) Balsamo <emanuele.balsamo@do-inc.co>, {{$year}}
*/

namespace {{$namespace}}\Exceptions;

use Doinc\Modules\SafeException\Exceptions\SafeException;

class {{$studly_param}} extends SafeException
{
    public function __construct()
    {
        parent::__construct(
            config("{{$snake}}.error_codes.{{$screaming_param}}.message"),
            config("{{$snake}}.error_codes.{{$screaming_param}}.code"),
            null
        );
    }
}
